# 📚 Dokumentasi Modul Desktop Kos Kosan Rahmat ZAW - Admin Panel

**Versi:** 1.0  
**Pembaruan Terakhir:** Mei 2026  
**Platform:** Windows Desktop (.NET Framework 4.8)  
**Teknologi:** C# dengan Windows Forms  
**Database:** REST API Integration (https://rahmatzaw.elarisnoir.my.id/api)

---

## 📋 Daftar Isi Modul

### 1. **SISTEM INTI**
- [01_Autentikasi_Login](01_Autentikasi_Login) - Proses login, manajemen sesi, dan keamanan
- [02_Navigasi_Sidebar](02_Navigasi_Sidebar) - Menu navigasi utama dan struktur navigasi aplikasi
- [03_Dashboard_Beranda](03_Dashboard_Beranda) - KPI cards, statistik real-time, dan grafik performa

### 2. **MANAJEMEN KAMAR**
- [04_Manajemen_Kamar_List](04_Manajemen_Kamar_List) - Tampilan list kamar, pencarian, filter, dan sorting
- [05_Edit_Kamar](05_Edit_Kamar) - Form editing kamar yang sudah ada di sistem
- [05_Tambah_Kamar](05_Tambah_Kamar) - Form penambahan data kamar baru ke sistem (akan dibuat)
- [07_Galeri_Kamar](07_Galeri_Kamar) - Manajemen foto/galeri untuk setiap kamar (akan dibuat)

### 3. **MANAJEMEN PENYEWA**
- [08_Manajemen_Penyewa_List](08_Manajemen_Penyewa_List) - Daftar penyewa, pencarian, dan filter data
- [09_Detail_Penyewa](09_Detail_Penyewa) - Informasi detail penyewa, riwayat pembayaran, dan data pemesanan

### 4. **MANAJEMEN PEMBAYARAN**
- [10_Manajemen_Pembayaran](10_Manajemen_Pembayaran) - List pembayaran, status, dan verifikasi pembayaran
- [11_Detail_Pembayaran](11_Detail_Pembayaran) - Detail transaksi, invoice, dan riwayat pembayaran per penyewa

### 5. **LAPORAN & ANALISIS**
- [12_Laporan_Bisnis](12_Laporan_Bisnis) - Laporan revenue, okupansi, dan insight bisnis

### 6. **INFRASTRUKTUR & INTEGRASI**
- [06_Integrasi_API](06_Integrasi_API) - Dokumentasi lengkap semua endpoint API dan cara integrasi
- [07_Model_Data](07_Model_Data) - Struktur data, mapping JSON, dan relasi data model
- [08_Sinkronisasi_Data](08_Sinkronisasi_Data) - Sistem real-time sync, caching, dan manajemen data lokal (akan dibuat)

---

## 🎯 Panduan Navigasi

### Untuk Pemula
Mulai dari dokumentasi dalam urutan ini untuk memahami alur aplikasi:
1. **00_INDEX.md** (Anda berada di sini) - Gambaran keseluruhan
2. **01_Autentikasi_Login.md** - Memahami cara login ke sistem
3. **02_Navigasi_Sidebar.md** - Memahami menu dan navigasi
4. **03_Dashboard_Beranda.md** - Memahami dashboard utama

### Untuk Developer
Jika Anda ingin mengembangkan fitur tertentu, baca dokumentasi dalam urutan:
1. **06_Integrasi_API.md** - Pahami endpoint dan contract API
2. **07_Model_Data.md** - Pahami struktur data dan mapping
3. **08_QUICK_REFERENCE.md** - Pahami code patterns dan best practices
4. Dokumentasi modul spesifik (misalnya 04_Manajemen_Kamar_List.md untuk fitur kamar)

### Untuk Testing & QA
Fokus pada bagian "Flow Aplikasi" dan "Skenario Testing" di setiap halaman untuk memahami use case.

---

## 🏗️ Arsitektur Aplikasi (Ringkas)

```
┌──────────────────────────────────────────────────────┐
│         FORM WINDOWS FORMS (UI Layer)                │
│  ├─ Form1 (Login)                                   │
│  ├─ Sidebar (Navigation)                            │
│  ├─ BerandaPage (Dashboard)                         │
│  ├─ DataKamar (Room Management)                     │
│  ├─ DataPenyewa (Tenant Management)                 │
│  ├─ PembayaranForm (Payment Management)             │
│  ├─ Report (Business Reports)                       │
│  └─ GalleryForm (Photo Management)                  │
└──────────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────────┐
│      BUSINESS LOGIC LAYER (Services)                │
│  ├─ ApiClient (HTTP Client & API Calls)             │
│  ├─ DataSyncManager (Real-Time Sync)                │
│  ├─ Session (User Session Management)               │
│  └─ DashboardStats (Dashboard Calculations)         │
└──────────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────────┐
│    DATA MODELS (DTO/Entity Classes)                 │
│  ├─ Kamar (Room)                                    │
│  ├─ Penyewa (Tenant)                                │
│  ├─ Pembayaran (Payment)                            │
│  ├─ LoginRequest / PaymentResponse                  │
│  └─ DashboardStats                                  │
└──────────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────────┐
│       BACKEND REST API (Remote Server)              │
│  BaseURL: https://rahmatzaw.elarisnoir.my.id/api   │
│                                                      │
│  Endpoints:                                          │
│  ├─ POST   /auth/login                             │
│  ├─ GET    /kamar, /kamar/{id}                     │
│  ├─ POST   /kamar                                   │
│  ├─ PUT    /kamar/{id}                              │
│  ├─ DELETE /kamar/{id}                              │
│  ├─ GET    /penyewa, /penyewa/{id}                 │
│  ├─ POST   /penyewa                                 │
│  ├─ PUT    /penyewa/{id}                            │
│  ├─ DELETE /penyewa/{id}                            │
│  ├─ GET    /payments                                │
│  ├─ PUT    /payments/{id}/confirm                  │
│  ├─ PUT    /payments/{id}/reject                   │
│  ├─ GET    /gallery                                 │
│  ├─ POST   /gallery                                 │
│  └─ DELETE /gallery/{id}                            │
└──────────────────────────────────────────────────────┘
```

---

## ⚡ Fitur Utama Aplikasi

| Fitur | Deskripsi | Status |\n|-------|-----------|--------|\n| **Autentikasi** | Login dengan username & password | ✅ Aktif |\n| **Dashboard** | KPI, charts, statistik real-time | ✅ Aktif |\n| **Manajemen Kamar** | CRUD kamar, filter, search | ✅ Aktif |\n| **Manajemen Penyewa** | CRUD penyewa, data detail | ✅ Aktif |\n| **Manajemen Pembayaran** | Konfirmasi pembayaran, verifikasi | ✅ Aktif |\n| **Galeri Foto** | Upload, hapus, preview foto kamar | ✅ Aktif |\n| **Laporan Bisnis** | Revenue, okupansi, insight | ✅ Aktif |\n| **Real-Time Sync** | Sinkronisasi data otomatis | ✅ Aktif |\n| **Bilingual Status** | Support Indonesian & English | ✅ Aktif |\n\n---

## 📌 Catatan Penting

### Keamanan
- Setiap request dilindungi dengan HTTP Cookies untuk autentikasi\n- Session timeout otomatis jika tidak ada aktivitas\n- Role-based access control untuk membatasi akses\n\n### Performa\n- Menggunakan async/await untuk non-blocking operations\n- Data caching untuk mengurangi beban API\n- Parallel loading untuk dashboard metrics\n\n### Bilingual Support\n- Status Kamar: Support format \"Tersedia / Available\", \"Penuh / Full\", dll\n- User dapat memilih bahasa saat filter atau edit form\n\n---\n\n## 🔗 Referensi Link\n\n- **Repository**: [Kost_SiguraGura GitHub](https://github.com/your-repo)\n- **API Documentation**: [Backend API Spec](../10_payment_system_backend_spec)\n- **Database Schema**: [Schema Documentation](../02_models)\n- **Architecture Guide**: [System Architecture](../01_core)\n\n---\n\n**Butuh bantuan?** Hubungi admin developer atau lihat troubleshooting guide di repository.

---

## 📚 Navigasi Dokumentasi

**← Sebelumnya:** Mulai dari sini  
**Berikutnya →** [01_Autentikasi_Login](01_Autentikasi_Login) - Modul Autentikasi & Login

**Daftar Lengkap:** [README_DOKUMENTASI](README_DOKUMENTASI)\n